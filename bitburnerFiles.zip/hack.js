/** @param {NS} ns **/
export async function main(ns) {
    var target = ns.args[0];
    await ns.hack(target);
    ns.tprintf("%s hack %s finished", new Date().toLocaleTimeString("en-US", { timeZone: "PST" }), target);
}